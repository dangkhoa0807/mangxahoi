import prisma from "@/libs/prisma";
import { deleteCache, deleteCachePattern } from "@/libs/redis";

async function main() {
  // try {
  //   // Delete all caches that match common patterns
  //   await Promise.all([
  //     // Any other caches
  //     deleteCachePattern("*"),
  //   ]);

  //   console.log("Successfully cleared all Redis caches");
  // } catch (error) {
  //   console.error("Error clearing Redis caches:", error);
  // }

  try {
    const comments = await prisma.comment.findMany({
      where: {
        postId: "674f5d21588b4d620ba6ae66",
        parentId: null,
      },
    });
    console.log(comments);
  } catch (error) {
    console.error("Error getting comments:", error);
  }
}

main();
