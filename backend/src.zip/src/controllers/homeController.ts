import { Hono } from "hono";

const homeController = new Hono();

export default homeController;
